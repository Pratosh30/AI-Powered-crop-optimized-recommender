# CropSense – Full Stack (React + Flask + ML)

Complete project with:
- Backend  – Flask REST API serving a trained Random Forest classifier (96.9% accuracy)
- Frontend – Modern React app with nature-themed UI

## Project Structure

  cropsense-fullstack/
  ├── backend/
  │   ├── app.py                    ← Flask server (CORS-enabled, JSON API)
  │   ├── model.py                  ← ML training script
  │   ├── model.pkl                 ← Trained Random Forest model
  │   ├── Crop_recommendation.csv   ← Training dataset (2200 samples)
  │   ├── requirements.txt          ← Python dependencies
  │   ├── static/
  │   └── templates/
  └── frontend/
      ├── package.json
      ├── public/
      └── src/
          ├── App.js
          ├── components/           ← Navbar, Footer, FeatureCard
          ├── pages/                ← LandingPage, PredictionPage
          └── utils/api.js          ← API layer (calls Flask)

## How to Run

Open TWO terminals:

### Terminal 1 — Flask Backend

  cd cropsense-fullstack/backend
  python -m venv venv
  source venv/bin/activate      # Windows: venv\Scripts\activate
  pip install -r requirements.txt
  python app.py
  # Running on http://localhost:5000

### Terminal 2 — React Frontend

  cd cropsense-fullstack/frontend
  npm install
  npm start
  # Opens at http://localhost:3000

Then open http://localhost:3000 in your browser.

## API Endpoint

POST http://localhost:5000/predict

Request JSON:
  { "Nitrogen": 90, "Phosphorus": 42, "Potassium": 43,
    "temperature": 20.8, "humidity": 82, "pH": 6.5, "rainfall": 202 }

Response:
  { "crop": "rice", "confidence": 97.3 }

## Authors
Mohammad Ahmad Siddiqui & Pratosh Singh Bhadauria
