from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import numpy as np
import pickle

flask_app = Flask(__name__)

# Allow React dev server (localhost:3000) to call this API
CORS(flask_app)

# Load the trained Random Forest model
model = pickle.load(open("model.pkl", "rb"))


@flask_app.route("/")
def Home():
    """Serve the original HTML frontend (legacy)."""
    return render_template("index.html")


@flask_app.route("/predict", methods=["POST"])
def predict():
    """
    Accepts JSON from the React frontend and returns the predicted crop.

    Expected JSON body:
    {
        "Nitrogen":    float,
        "Phosphorus":  float,
        "Potassium":   float,
        "temperature": float,
        "humidity":    float,
        "pH":          float,
        "rainfall":    float
    }

    Returns:
    {
        "crop":       str,
        "confidence": float  -- model confidence in %
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({"error": "No JSON data received"}), 400

        features = [[
            float(data["Nitrogen"]),
            float(data["Phosphorus"]),
            float(data["Potassium"]),
            float(data["temperature"]),
            float(data["humidity"]),
            float(data["pH"]),
            float(data["rainfall"]),
        ]]

        prediction = model.predict(features)

        # Real confidence score from the model
        proba = model.predict_proba(features)
        confidence = round(float(proba.max()) * 100, 1)

        return jsonify({
            "crop":       str(prediction[0]),
            "confidence": confidence
        })

    except KeyError as e:
        return jsonify({"error": f"Missing field: {str(e)}"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    flask_app.run(debug=True, port=5000)
