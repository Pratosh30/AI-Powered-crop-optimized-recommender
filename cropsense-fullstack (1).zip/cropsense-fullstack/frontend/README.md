# 🌾 CropSense – AI Crop Recommendation System

A modern, production-grade React frontend for the **Crop Recommendation System** ML project.  
Uses a trained Random Forest classifier (96.9% accuracy) to recommend the best crop based on soil nutrients and climate data.

---

## 📁 Project Structure

```
crop-recommendation-system/
│
├── public/
│   └── index.html                  # HTML entry point with Google Fonts
│
├── src/
│   ├── index.js                    # React DOM render entry
│   ├── index.css                   # Global styles, CSS variables, animations
│   ├── App.js                      # Root component with React Router setup
│   │
│   ├── components/                 # Reusable UI components
│   │   ├── Navbar.js               # Sticky navbar with scroll effect + mobile menu
│   │   ├── Navbar.css
│   │   ├── Footer.js               # Site footer with links and credits
│   │   ├── Footer.css
│   │   ├── FeatureCard.js          # Feature highlight card (icon + title + desc)
│   │   └── FeatureCard.css
│   │
│   ├── pages/                      # Route-level page components
│   │   ├── LandingPage.js          # Hero, Features, How It Works, Education, CTA
│   │   ├── LandingPage.css
│   │   ├── PredictionPage.js       # Form, validation, result card, loading state
│   │   └── PredictionPage.css
│   │
│   └── utils/
│       └── api.js                  # API layer (mock + real Flask integration)
│
├── .env.example                    # Environment variable template
├── package.json                    # Dependencies and scripts
└── README.md                       # This file
```

---

## 🚀 Getting Started

### Prerequisites

- **Node.js** v16 or higher
- **npm** v7 or higher

Check versions:
```bash
node --version
npm --version
```

---

### 1. Install Dependencies

```bash
cd crop-recommendation-system
npm install
```

This installs:
- `react` + `react-dom`
- `react-router-dom` (client-side routing)
- `react-icons` (icon library)

---

### 2. Configure Environment (Optional)

```bash
cp .env.example .env
```

Edit `.env` to point to your Flask backend:
```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_MOCK=false
```

> By default the app runs in **mock mode** — no backend needed for development.

---

### 3. Start Development Server

```bash
npm start
```

Opens at **http://localhost:3000**

---

### 4. Build for Production

```bash
npm run build
```

Outputs optimized static files to `/build/` — deploy to any static host (Netlify, Vercel, GitHub Pages).

---

## 🔗 Connecting to the Flask Backend

### Backend changes needed

Your existing `app.py` returns an HTML page on `/predict`. To work with React, add a **JSON endpoint**:

```python
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import numpy as np
import pickle

flask_app = Flask(__name__)
CORS(flask_app)  # Allow React dev server (localhost:3000)
model = pickle.load(open("model.pkl", "rb"))

@flask_app.route("/")
def Home():
    return render_template("index.html")

# ── NEW: JSON API endpoint for React ──
@flask_app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    features = [[
        float(data["Nitrogen"]),
        float(data["Phosphorus"]),
        float(data["Potassium"]),
        float(data["temperature"]),
        float(data["humidity"]),
        float(data["pH"]),
        float(data["rainfall"]),
    ]]
    prediction = model.predict(features)
    return jsonify({
        "crop": str(prediction[0]),
        "confidence": 95
    })

if __name__ == "__main__":
    flask_app.run(debug=True)
```

Install CORS support:
```bash
pip install flask-cors
```

### Enable in React

Open `src/utils/api.js` and change:
```js
const MOCK_MODE = false;  // line 15
```

The API call in `api.js` will automatically use `REACT_APP_API_URL` from your `.env`.

---

## 🎨 Design System

| Token | Value | Usage |
|---|---|---|
| `--forest` | `#1a3c1a` | Primary dark green |
| `--leaf` | `#4a8c3f` | Accent green |
| `--sprout` | `#6db560` | Light green highlights |
| `--sand` | `#c9a96e` | Earthy accent |
| `--cream` | `#f7f4ee` | Page background |
| Font Display | Playfair Display | Headings & titles |
| Font Body | DM Sans | All body text |

---

## 📄 Routes

| Path | Component | Description |
|---|---|---|
| `/` | `LandingPage` | Hero, features, how-it-works, education |
| `/predict` | `PredictionPage` | Prediction form + result display |

---

## 🧩 Key Components

| Component | File | Purpose |
|---|---|---|
| `Navbar` | `components/Navbar.js` | Sticky nav, scroll-aware, mobile drawer |
| `Footer` | `components/Footer.js` | Links, credits, gradient top bar |
| `FeatureCard` | `components/FeatureCard.js` | Reusable card with icon, title, desc |
| `FormField` | inside `PredictionPage.js` | Input with validation, unit badge, tip |
| `ResultCard` | inside `PredictionPage.js` | Prediction result with confidence bar |
| `InfoPanel` | inside `PredictionPage.js` | Quick reference ranges sidebar |

---

## 📦 Sample Data (for testing)

Four sample presets are available on the Predict page:

| Crop | N | P | K | Temp | Humidity | pH | Rainfall |
|---|---|---|---|---|---|---|---|
| Rice | 90 | 42 | 43 | 20.8 | 82 | 6.5 | 202 |
| Wheat | 90 | 50 | 35 | 15.5 | 65 | 7.1 | 85 |
| Maize | 78 | 48 | 22 | 23.3 | 71 | 6.2 | 103 |
| Cotton | 117 | 47 | 20 | 23.7 | 80 | 6.5 | 56 |

---

## 👨‍💻 Authors

**Mohammad Ahmad Siddiqui** & **Pratosh Singh Bhadauria**  
Technologies: Python · Flask · Random Forest ML · React.js · CSS

---

## 📝 License

MIT — free for academic and personal use.
