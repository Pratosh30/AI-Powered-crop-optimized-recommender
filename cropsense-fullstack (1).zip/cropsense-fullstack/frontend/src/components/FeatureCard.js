import React from 'react';
import './FeatureCard.css';

/**
 * FeatureCard – Displays a single feature with icon, title, and description.
 *
 * Props:
 *  icon      – React element (icon component)
 *  title     – Card heading string
 *  description – Body text
 *  delay     – CSS animation delay class (e.g. 'delay-100')
 *  accent    – optional accent color override (CSS color string)
 */
function FeatureCard({ icon, title, description, delay = '', accent }) {
  return (
    <div className={`feature-card animate-fade-up ${delay}`}>
      {/* Icon badge */}
      <div
        className="feature-card__icon"
        style={accent ? { background: accent } : {}}
      >
        {icon}
      </div>

      <h3 className="feature-card__title">{title}</h3>
      <p  className="feature-card__desc">{description}</p>
    </div>
  );
}

export default FeatureCard;
