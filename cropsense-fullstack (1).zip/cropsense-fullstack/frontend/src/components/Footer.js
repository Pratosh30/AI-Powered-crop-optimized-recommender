import React from 'react';
import { Link } from 'react-router-dom';
import { GiWheat } from 'react-icons/gi';
import { FiGithub, FiMail } from 'react-icons/fi';
import './Footer.css';

/**
 * Footer – Site-wide footer with branding, quick links, and credits.
 */
function Footer() {
  return (
    <footer className="footer">
      {/* Decorative top border */}
      <div className="footer__top-bar" />

      <div className="footer__body container">
        {/* Brand column */}
        <div className="footer__brand-col">
          <div className="footer__logo">
            <span className="footer__logo-icon"><GiWheat /></span>
            <span className="footer__logo-text">Crop<strong>Sense</strong></span>
          </div>
          <p className="footer__tagline">
            Empowering farmers with AI-driven crop intelligence for smarter harvests.
          </p>
          <div className="footer__socials">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="footer__social-link" aria-label="GitHub">
              <FiGithub />
            </a>
            <a href="mailto:info@cropsense.ai" className="footer__social-link" aria-label="Email">
              <FiMail />
            </a>
          </div>
        </div>

        {/* Links column */}
        <div className="footer__links-col">
          <h4 className="footer__heading">Navigate</h4>
          <Link to="/"         className="footer__link">Home</Link>
          <Link to="/predict"  className="footer__link">Predict Crop</Link>
          <a href="/#features" className="footer__link">Features</a>
          <a href="/#about"    className="footer__link">About</a>
        </div>

        {/* Tech column */}
        <div className="footer__links-col">
          <h4 className="footer__heading">Technology</h4>
          <span className="footer__link">Python & Flask</span>
          <span className="footer__link">Random Forest ML</span>
          <span className="footer__link">React.js Frontend</span>
          <span className="footer__link">96.9% Accuracy</span>
        </div>
      </div>

      {/* Copyright bar */}
      <div className="footer__bottom container">
        <p>
          © {new Date().getFullYear()} CropSense. Built by{' '}
          <strong>Mohammad Ahmad Siddiqui</strong> &amp;{' '}
          <strong>Pratosh Singh Bhadauria</strong>.
        </p>
        <p className="footer__sub">ML-powered agriculture for a smarter world 🌾</p>
      </div>
    </footer>
  );
}

export default Footer;
