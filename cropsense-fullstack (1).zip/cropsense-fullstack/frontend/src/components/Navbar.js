import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { GiWheat } from 'react-icons/gi';
import { HiMenuAlt3, HiX } from 'react-icons/hi';
import './Navbar.css';

/**
 * Navbar – Sticky navigation with scroll-aware styling and mobile menu.
 */
function Navbar() {
  const [scrolled, setScrolled]   = useState(false);
  const [menuOpen, setMenuOpen]   = useState(false);
  const location                  = useLocation();

  /* Detect scroll to add frosted-glass background */
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  /* Close mobile menu on route change */
  useEffect(() => { setMenuOpen(false); }, [location]);

  const isActive = (path) => location.pathname === path;

  return (
    <header className={`navbar ${scrolled ? 'navbar--scrolled' : ''}`}>
      <div className="navbar__inner container">
        {/* Brand */}
        <Link to="/" className="navbar__brand">
          <span className="navbar__brand-icon">
            <GiWheat />
          </span>
          <span className="navbar__brand-text">
            Crop<strong>Sense</strong>
          </span>
        </Link>

        {/* Desktop nav links */}
        <nav className="navbar__links">
          <Link to="/"        className={`navbar__link ${isActive('/')        ? 'navbar__link--active' : ''}`}>Home</Link>
          <Link to="/predict" className={`navbar__link ${isActive('/predict') ? 'navbar__link--active' : ''}`}>Predict</Link>
          <a href="/#features" className="navbar__link">Features</a>
          <a href="/#about"    className="navbar__link">About</a>
        </nav>

        {/* CTA */}
        <Link to="/predict" className="navbar__cta">
          Try Now →
        </Link>

        {/* Hamburger (mobile) */}
        <button
          className="navbar__hamburger"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <HiX /> : <HiMenuAlt3 />}
        </button>
      </div>

      {/* Mobile drawer */}
      <div className={`navbar__drawer ${menuOpen ? 'navbar__drawer--open' : ''}`}>
        <Link to="/"        className="navbar__drawer-link">Home</Link>
        <Link to="/predict" className="navbar__drawer-link">Predict Crop</Link>
        <a href="/#features" className="navbar__drawer-link">Features</a>
        <a href="/#about"    className="navbar__drawer-link">About</a>
      </div>
    </header>
  );
}

export default Navbar;
