import React from 'react';
import { Link } from 'react-router-dom';
import {
  GiWheat, GiWateringCan, GiPlantSeed, GiSun,
} from 'react-icons/gi';
import {
  FiCpu, FiBarChart2, FiClock, FiShield, FiSun as FiLeaf, FiUsers,
} from 'react-icons/fi';

import FeatureCard from '../components/FeatureCard';
import './LandingPage.css';

/* ── Feature data ── */
const FEATURES = [
  {
    icon: <FiCpu />,
    title: 'ML-Powered Predictions',
    description:
      'Random Forest model trained on thousands of crop samples delivers 96.9% accuracy in recommending the right crop.',
    delay: 'delay-100',
    accent: 'linear-gradient(135deg, #2d5a27, #4a8c3f)',
  },
  {
    icon: <FiBarChart2 />,
    title: 'Soil Analysis',
    description:
      'Enter N, P, K levels with pH and our model analyses the complete soil profile to match it with ideal crops.',
    delay: 'delay-200',
    accent: 'linear-gradient(135deg, #6b4c2a, #c9a96e)',
  },
  {
    icon: <FiClock />,
    title: 'Instant Results',
    description:
      'Get crop recommendations in milliseconds. No waiting, no complex reports — just actionable advice.',
    delay: 'delay-300',
    accent: 'linear-gradient(135deg, #1a5c7a, #4aabcc)',
  },
  {
    icon: <FiLeaf />,
    title: 'Climate-Aware',
    description:
      'Temperature, humidity, and rainfall data are factored in to ensure the crop thrives in your local environment.',
    delay: 'delay-400',
    accent: 'linear-gradient(135deg, #4a8c3f, #8fbd7c)',
  },
  {
    icon: <FiShield />,
    title: 'Research-Backed',
    description:
      'Built on verified agricultural datasets and peer-reviewed farming science — data you can trust.',
    delay: 'delay-500',
    accent: 'linear-gradient(135deg, #5a2d82, #9a6bc2)',
  },
  {
    icon: <FiUsers />,
    title: 'Farmer Friendly',
    description:
      'Designed for farmers with minimal technical knowledge. Simple input, clear output — agriculture made smarter.',
    delay: 'delay-600',
    accent: 'linear-gradient(135deg, #8c3f3f, #cc7a4a)',
  },
];

/* ── How it works steps ── */
const STEPS = [
  { num: '01', icon: <GiWateringCan />, title: 'Test Your Soil', desc: 'Collect soil NPK, pH values from your field or laboratory report.' },
  { num: '02', icon: <GiSun />,         title: 'Enter Climate Data', desc: 'Input local temperature, humidity, and average rainfall readings.' },
  { num: '03', icon: <FiCpu />,         title: 'AI Analyses', desc: 'Our Random Forest model processes all 7 parameters simultaneously.' },
  { num: '04', icon: <GiPlantSeed />,   title: 'Get Your Crop', desc: 'Receive a confident crop recommendation with supporting details.' },
];

/* ── Soil nutrient info ── */
const NUTRIENTS = [
  { label: 'Nitrogen (N)',   short: 'N',  color: '#4a8c3f', desc: 'Drives leafy green growth and chlorophyll production.' },
  { label: 'Phosphorus (P)', short: 'P',  color: '#8c6a2f', desc: 'Essential for root development and energy transfer.' },
  { label: 'Potassium (K)',  short: 'K',  color: '#3f6a8c', desc: 'Improves disease resistance and overall crop quality.' },
  { label: 'Soil pH',        short: 'pH', color: '#8c3f6a', desc: 'Controls nutrient availability and soil microorganism activity.' },
];

/* ═══════════════════════════════════════════ */

function LandingPage() {
  return (
    <div className="landing">

      {/* ══ HERO ══ */}
      <section className="hero">
        {/* Decorative background elements */}
        <div className="hero__bg-circle hero__bg-circle--1" />
        <div className="hero__bg-circle hero__bg-circle--2" />
        <div className="hero__bg-dots" />

        <div className="hero__content container">
          <div className="hero__text">
            {/* Badge */}
            <div className="hero__badge animate-fade-up">
              <GiWheat className="hero__badge-icon" />
              <span>96.9% ML Model Accuracy</span>
            </div>

            {/* Headline */}
            <h1 className="hero__title animate-fade-up delay-100">
              Smarter Farming <br />
              <span className="hero__title-accent">Starts with Data</span>
            </h1>

            {/* Subheading */}
            <p className="hero__subtitle animate-fade-up delay-200">
              CropSense uses Machine Learning to analyse soil nutrients, climate
              conditions, and environmental factors — recommending the perfect
              crop for your land in seconds.
            </p>

            {/* CTA buttons */}
            <div className="hero__actions animate-fade-up delay-300">
              <Link to="/predict" className="btn btn--primary">
                Get Started Free →
              </Link>
              <a href="#how-it-works" className="btn btn--ghost">
                See How It Works
              </a>
            </div>

            {/* Stats strip */}
            <div className="hero__stats animate-fade-up delay-400">
              <div className="hero__stat">
                <strong>22+</strong>
                <span>Crop types</span>
              </div>
              <div className="hero__stat-divider" />
              <div className="hero__stat">
                <strong>7</strong>
                <span>Parameters</span>
              </div>
              <div className="hero__stat-divider" />
              <div className="hero__stat">
                <strong>96.9%</strong>
                <span>Accuracy</span>
              </div>
            </div>
          </div>

          {/* Hero illustration */}
          <div className="hero__visual animate-fade-up delay-200">
            <div className="hero__card-mockup">
              <div className="hero__mockup-header">
                <span className="hero__dot" style={{background:'#ff6b6b'}}/>
                <span className="hero__dot" style={{background:'#ffd93d'}}/>
                <span className="hero__dot" style={{background:'#6bcb77'}}/>
                <span className="hero__mockup-title">AI Prediction</span>
              </div>
              <div className="hero__mockup-body">
                <div className="hero__mockup-result">
                  <span className="hero__result-emoji">🌾</span>
                  <div>
                    <p className="hero__result-label">Recommended Crop</p>
                    <p className="hero__result-name">Rice</p>
                  </div>
                  <span className="hero__result-conf">94%</span>
                </div>
                <div className="hero__mockup-bars">
                  {[
                    { label: 'Nitrogen',  pct: 72 },
                    { label: 'Humidity',  pct: 85 },
                    { label: 'Rainfall',  pct: 60 },
                  ].map((b) => (
                    <div key={b.label} className="hero__mockup-bar">
                      <span>{b.label}</span>
                      <div className="hero__bar-track">
                        <div className="hero__bar-fill" style={{width:`${b.pct}%`}}/>
                      </div>
                      <span>{b.pct}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Floating leaf accents */}
            <div className="hero__leaf hero__leaf--1">🌿</div>
            <div className="hero__leaf hero__leaf--2">🍃</div>
            <div className="hero__leaf hero__leaf--3">☘️</div>
          </div>
        </div>
      </section>

      {/* ══ FEATURES ══ */}
      <section className="section section--light" id="features">
        <div className="container">
          <div className="section-header">
            <div className="section-badge">Features</div>
            <h2 className="section-title">Everything a farmer needs</h2>
            <p className="section-subtitle">
              Six powerful capabilities, one simple interface — designed to make
              data-driven farming accessible to everyone.
            </p>
          </div>

          <div className="features-grid">
            {FEATURES.map((f) => (
              <FeatureCard key={f.title} {...f} />
            ))}
          </div>
        </div>
      </section>

      {/* ══ HOW IT WORKS ══ */}
      <section className="section section--green" id="how-it-works">
        <div className="container">
          <div className="section-header">
            <div className="section-badge section-badge--light">Process</div>
            <h2 className="section-title section-title--light">
              How CropSense Works
            </h2>
            <p className="section-subtitle section-subtitle--light">
              Four simple steps from soil sample to crop recommendation.
            </p>
          </div>

          <div className="steps-grid">
            {STEPS.map((step, i) => (
              <div key={step.num} className={`step animate-fade-up delay-${(i+1)*100}`}>
                <div className="step__number">{step.num}</div>
                <div className="step__icon">{step.icon}</div>
                <h3 className="step__title">{step.title}</h3>
                <p  className="step__desc">{step.desc}</p>
                {i < STEPS.length - 1 && <div className="step__connector" />}
              </div>
            ))}
          </div>

          <div className="section-cta">
            <Link to="/predict" className="btn btn--white">
              Start Your Prediction →
            </Link>
          </div>
        </div>
      </section>

      {/* ══ NUTRIENT EDUCATION ══ */}
      <section className="section section--light" id="about">
        <div className="container">
          <div className="section-header">
            <div className="section-badge">Learn</div>
            <h2 className="section-title">Understanding Soil & Climate</h2>
            <p className="section-subtitle">
              Our model reads 7 parameters. Here's what each one means for your crop's success.
            </p>
          </div>

          <div className="nutrients-grid">
            {NUTRIENTS.map((n) => (
              <div key={n.label} className="nutrient-card animate-fade-up">
                <div
                  className="nutrient-card__badge"
                  style={{ background: n.color }}
                >
                  {n.short}
                </div>
                <h4 className="nutrient-card__label">{n.label}</h4>
                <p  className="nutrient-card__desc">{n.desc}</p>
              </div>
            ))}
          </div>

          {/* Accuracy banner */}
          <div className="accuracy-banner animate-fade-up">
            <div className="accuracy-banner__text">
              <h3>Random Forest Classifier</h3>
              <p>Trained on 2,200+ labelled soil-crop samples. Cross-validated across 5 folds.</p>
            </div>
            <div className="accuracy-banner__stat">
              <span className="accuracy-banner__num">96.9%</span>
              <span className="accuracy-banner__label">Test Accuracy</span>
            </div>
          </div>
        </div>
      </section>

      {/* ══ CTA BANNER ══ */}
      <section className="cta-banner">
        <div className="container">
          <GiWheat className="cta-banner__icon" />
          <h2 className="cta-banner__title">Ready to find the right crop?</h2>
          <p className="cta-banner__sub">
            Enter your soil and climate data — get an instant AI-powered recommendation.
          </p>
          <Link to="/predict" className="btn btn--primary btn--lg">
            Predict My Crop →
          </Link>
        </div>
      </section>

    </div>
  );
}

export default LandingPage;
