import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  FiThermometer, FiDroplet, FiCloud, FiAlertCircle,
  FiCheckCircle, FiRefreshCw, FiArrowLeft, FiActivity,
} from 'react-icons/fi';
import { GiPlantSeed, GiWheat } from 'react-icons/gi';
import { predictCrop } from '../utils/api';
import './PredictionPage.css';

/* ── Field configuration ── */
const FIELDS = [
  {
    id:          'nitrogen',
    label:       'Nitrogen (N)',
    placeholder: 'e.g. 90',
    unit:        'kg/ha',
    icon:        <FiActivity />,
    min:         0,
    max:         140,
    tip:         'Recommended range: 0–140 kg/ha',
    color:       'green',
  },
  {
    id:          'phosphorus',
    label:       'Phosphorus (P)',
    placeholder: 'e.g. 42',
    unit:        'kg/ha',
    icon:        <FiActivity />,
    min:         5,
    max:         145,
    tip:         'Recommended range: 5–145 kg/ha',
    color:       'brown',
  },
  {
    id:          'potassium',
    label:       'Potassium (K)',
    placeholder: 'e.g. 43',
    unit:        'kg/ha',
    icon:        <FiActivity />,
    min:         5,
    max:         205,
    tip:         'Recommended range: 5–205 kg/ha',
    color:       'blue',
  },
  {
    id:          'temperature',
    label:       'Temperature',
    placeholder: 'e.g. 20.8',
    unit:        '°C',
    icon:        <FiThermometer />,
    min:         8,
    max:         44,
    tip:         'Average daytime temperature in °C',
    color:       'orange',
  },
  {
    id:          'humidity',
    label:       'Humidity',
    placeholder: 'e.g. 82',
    unit:        '%',
    icon:        <FiDroplet />,
    min:         14,
    max:         100,
    tip:         'Average relative humidity (%)',
    color:       'teal',
  },
  {
    id:          'ph',
    label:       'Soil pH',
    placeholder: 'e.g. 6.5',
    unit:        'pH',
    icon:        <FiActivity />,
    min:         3.5,
    max:         9.5,
    tip:         'pH 6–7 is ideal for most crops',
    color:       'purple',
  },
  {
    id:          'rainfall',
    label:       'Rainfall',
    placeholder: 'e.g. 202',
    unit:        'mm',
    icon:        <FiCloud />,
    min:         20,
    max:         300,
    tip:         'Annual/seasonal average rainfall in mm',
    color:       'sky',
  },
];

/* ── Sample data sets ── */
const SAMPLES = {
  rice:    { nitrogen: 90,  phosphorus: 42,  potassium: 43,  temperature: 20.8, humidity: 82,  ph: 6.5, rainfall: 202 },
  wheat:   { nitrogen: 90,  phosphorus: 50,  potassium: 35,  temperature: 15.5, humidity: 65,  ph: 7.1, rainfall: 85  },
  maize:   { nitrogen: 78,  phosphorus: 48,  potassium: 22,  temperature: 23.3, humidity: 71,  ph: 6.2, rainfall: 103 },
  cotton:  { nitrogen: 117, phosphorus: 47,  potassium: 20,  temperature: 23.7, humidity: 80,  ph: 6.5, rainfall: 56  },
};

/* ══════════════════════════════════════════ */

function PredictionPage() {
  const [values,   setValues]   = useState({ nitrogen: '', phosphorus: '', potassium: '', temperature: '', humidity: '', ph: '', rainfall: '' });
  const [errors,   setErrors]   = useState({});
  const [loading,  setLoading]  = useState(false);
  const [result,   setResult]   = useState(null);
  const [apiError, setApiError] = useState('');

  /* ── Validation ── */
  function validate() {
    const errs = {};
    FIELDS.forEach(({ id, label, min, max }) => {
      const v = parseFloat(values[id]);
      if (values[id] === '') {
        errs[id] = `${label} is required`;
      } else if (isNaN(v)) {
        errs[id] = `${label} must be a number`;
      } else if (v < min || v > max) {
        errs[id] = `${label} must be between ${min} and ${max}`;
      }
    });
    return errs;
  }

  /* ── Handle input change ── */
  function handleChange(id, raw) {
    setValues((prev) => ({ ...prev, [id]: raw }));
    if (errors[id]) setErrors((prev) => ({ ...prev, [id]: '' }));
  }

  /* ── Fill sample data ── */
  function fillSample(cropKey) {
    setValues(SAMPLES[cropKey]);
    setErrors({});
    setResult(null);
    setApiError('');
  }

  /* ── Submit ── */
  async function handleSubmit(e) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }

    setLoading(true);
    setResult(null);
    setApiError('');

    try {
      const crop = await predictCrop(values);
      setResult(crop);
    } catch (err) {
      setApiError(err.message || 'Prediction failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  /* ── Reset ── */
  function handleReset() {
    setValues({ nitrogen: '', phosphorus: '', potassium: '', temperature: '', humidity: '', ph: '', rainfall: '' });
    setErrors({});
    setResult(null);
    setApiError('');
  }

  /* ──────────── Render ──────────── */
  return (
    <div className="predict-page">

      {/* ── Decorative header strip ── */}
      <div className="predict-page__header">
        <div className="predict-page__header-bg" />
        <div className="container">
          <Link to="/" className="predict-page__back">
            <FiArrowLeft /> Back to Home
          </Link>
          <div className="predict-page__heading">
            <div className="predict-page__heading-icon">
              <GiWheat />
            </div>
            <div>
              <h1 className="predict-page__title">Crop Prediction</h1>
              <p className="predict-page__subtitle">
                Fill in your soil &amp; climate values to get an instant AI recommendation
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container">
        <div className="predict-page__layout">

          {/* ════ Left – Form ════ */}
          <div className="predict-page__form-col">

            {/* Sample data buttons */}
            <div className="sample-strip">
              <span className="sample-strip__label">Try a sample:</span>
              {Object.keys(SAMPLES).map((key) => (
                <button
                  key={key}
                  type="button"
                  className="sample-strip__btn"
                  onClick={() => fillSample(key)}
                >
                  {key.charAt(0).toUpperCase() + key.slice(1)}
                </button>
              ))}
            </div>

            {/* Main form */}
            <form className="pred-form" onSubmit={handleSubmit} noValidate>
              <div className="pred-form__grid">
                {FIELDS.map((field) => (
                  <FormField
                    key={field.id}
                    field={field}
                    value={values[field.id]}
                    error={errors[field.id]}
                    onChange={handleChange}
                  />
                ))}
              </div>

              {/* Submit row */}
              <div className="pred-form__actions">
                <button
                  type="submit"
                  className="pred-form__submit"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="pred-form__spinner" />
                      Analysing…
                    </>
                  ) : (
                    <>
                      <GiPlantSeed />
                      Predict Crop
                    </>
                  )}
                </button>

                <button
                  type="button"
                  className="pred-form__reset"
                  onClick={handleReset}
                >
                  <FiRefreshCw />
                  Reset
                </button>
              </div>
            </form>
          </div>

          {/* ════ Right – Result / Info ════ */}
          <div className="predict-page__result-col">

            {/* Loading skeleton */}
            {loading && <LoadingSkeleton />}

            {/* Error */}
            {!loading && apiError && (
              <div className="result-error animate-scale-in">
                <FiAlertCircle className="result-error__icon" />
                <div>
                  <h3>Something went wrong</h3>
                  <p>{apiError}</p>
                </div>
              </div>
            )}

            {/* Result card */}
            {!loading && result && (
              <ResultCard result={result} />
            )}

            {/* Placeholder when idle */}
            {!loading && !result && !apiError && (
              <IdlePlaceholder />
            )}

            {/* Info sidebar */}
            <InfoPanel />
          </div>

        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────
   Sub-components
───────────────────────────────────────────────── */

/** A single form input field with label, unit badge, tip, and error. */
function FormField({ field, value, error, onChange }) {
  return (
    <div className={`form-field form-field--${field.color} ${error ? 'form-field--error' : ''}`}>
      <label className="form-field__label" htmlFor={field.id}>
        <span className="form-field__icon">{field.icon}</span>
        {field.label}
      </label>

      <div className="form-field__input-wrap">
        <input
          id={field.id}
          type="number"
          step="any"
          className="form-field__input"
          placeholder={field.placeholder}
          value={value}
          min={field.min}
          max={field.max}
          onChange={(e) => onChange(field.id, e.target.value)}
          aria-describedby={error ? `${field.id}-err` : `${field.id}-tip`}
        />
        <span className="form-field__unit">{field.unit}</span>
      </div>

      {error ? (
        <p id={`${field.id}-err`} className="form-field__msg form-field__msg--error">
          <FiAlertCircle /> {error}
        </p>
      ) : (
        <p id={`${field.id}-tip`} className="form-field__msg">
          {field.tip}
        </p>
      )}
    </div>
  );
}

/** Animated loading skeleton while waiting for prediction. */
function LoadingSkeleton() {
  return (
    <div className="loading-skeleton animate-fade-in">
      <div className="loading-skeleton__pulse">
        <div className="loading-skeleton__icon">🔄</div>
        <h3>Analysing your data…</h3>
        <p>Our Random Forest model is processing your soil &amp; climate inputs.</p>
        <div className="loading-skeleton__bars">
          {[80, 60, 90, 45].map((w, i) => (
            <div key={i} className="loading-skeleton__bar" style={{ width: `${w}%` }} />
          ))}
        </div>
      </div>
    </div>
  );
}

/** Idle placeholder when no prediction yet. */
function IdlePlaceholder() {
  return (
    <div className="idle-placeholder">
      <div className="idle-placeholder__icon">🌱</div>
      <h3>Your recommendation appears here</h3>
      <p>
        Enter your soil nutrient values and climate data, then hit{' '}
        <strong>Predict Crop</strong> to see the AI's suggestion.
      </p>
    </div>
  );
}

/** Displayed when prediction returns successfully. */
function ResultCard({ result }) {
  return (
    <div className="result-card animate-scale-in">
      {/* Header */}
      <div className="result-card__header">
        <FiCheckCircle className="result-card__check" />
        <span>Prediction Complete</span>
      </div>

      {/* Main result */}
      <div className="result-card__body">
        <div className="result-card__emoji">{result.emoji}</div>
        <p className="result-card__sub">Recommended crop for your conditions</p>
        <h2 className="result-card__name">{result.name}</h2>

        {/* Confidence bar */}
        <div className="result-card__conf">
          <div className="result-card__conf-header">
            <span>Model confidence</span>
            <strong>{result.confidence}%</strong>
          </div>
          <div className="result-card__conf-track">
            <div
              className="result-card__conf-fill"
              style={{ width: `${result.confidence}%` }}
            />
          </div>
        </div>

        {/* Description */}
        <p className="result-card__desc">{result.description}</p>

        {/* Season chip */}
        <div className="result-card__season">
          <GiPlantSeed />
          <span><strong>Season:</strong> {result.season}</span>
        </div>
      </div>

      <div className="result-card__footer">
        Results are AI-generated suggestions. Always consult your local agriculture department.
      </div>
    </div>
  );
}

/** Static informational sidebar panel. */
function InfoPanel() {
  return (
    <div className="info-panel">
      <h4 className="info-panel__title">Quick Reference</h4>

      <div className="info-panel__rows">
        {[
          { emoji: '🌡️', label: 'Temperature', range: '8 – 44 °C'    },
          { emoji: '💧', label: 'Humidity',    range: '14 – 100 %'   },
          { emoji: '🌧️', label: 'Rainfall',   range: '20 – 300 mm'  },
          { emoji: '⚗️', label: 'Soil pH',    range: '3.5 – 9.5'    },
          { emoji: '🧪', label: 'N / P / K',  range: '0–140 / 5–145 / 5–205' },
        ].map((r) => (
          <div key={r.label} className="info-panel__row">
            <span className="info-panel__row-icon">{r.emoji}</span>
            <span className="info-panel__row-label">{r.label}</span>
            <span className="info-panel__row-range">{r.range}</span>
          </div>
        ))}
      </div>

      <div className="info-panel__tip">
        💡 Values outside the training range may reduce prediction accuracy.
      </div>
    </div>
  );
}

export default PredictionPage;
