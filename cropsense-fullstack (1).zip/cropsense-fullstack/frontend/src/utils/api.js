/**
 * api.js – API utility layer.
 *
 * MOCK_MODE = true  → uses built-in dummy data (no backend needed)
 * MOCK_MODE = false → calls your real Flask server at BACKEND_URL
 *
 * Set REACT_APP_API_URL in .env to change the backend URL.
 */

const MOCK_MODE   = false;   // ← false = use real Flask backend
const BACKEND_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

/* ─── Crop data used in mock responses ─── */
const CROP_DATABASE = [
  { name: 'Rice',         emoji: '🌾', description: 'Ideal for your soil conditions. Grows best in flooded paddies with warm, humid climates.',           season: 'Kharif (Jun–Nov)', confidence: 94 },
  { name: 'Wheat',        emoji: '🌾', description: 'Perfect for cool, dry conditions. A staple crop requiring well-drained loamy soil.',                  season: 'Rabi (Nov–Apr)',   confidence: 91 },
  { name: 'Maize',        emoji: '🌽', description: 'Excellent match! Versatile crop that thrives in warm temperatures and moderate rainfall.',             season: 'Kharif (Jun–Sep)', confidence: 89 },
  { name: 'Chickpea',     emoji: '🫘', description: 'Great nitrogen-fixing legume suited to dry, cool growing conditions.',                                season: 'Rabi (Oct–Mar)',   confidence: 87 },
  { name: 'Kidney Beans', emoji: '🫘', description: 'Thrives in warm, moderate-humidity environments with neutral to slightly acidic soil.',               season: 'Kharif',           confidence: 85 },
  { name: 'Cotton',       emoji: '☁️', description: 'Suitable for high-temperature, low-humidity readings with well-drained soil.',                        season: 'Kharif (Apr–Nov)', confidence: 88 },
  { name: 'Mango',        emoji: '🥭', description: 'Your climate data matches mango growing conditions perfectly. Expect a tropical yield.',              season: 'Summer (Mar–Jun)', confidence: 92 },
  { name: 'Banana',       emoji: '🍌', description: 'High humidity and warm temperature readings indicate excellent banana cultivation potential.',         season: 'Year-round',       confidence: 90 },
  { name: 'Coffee',       emoji: '☕', description: 'Your pH and humidity values align well with coffee cultivation in hilly regions.',                    season: 'Year-round',       confidence: 83 },
  { name: 'Coconut',      emoji: '🥥', description: 'High humidity and warm climate make this a great coastal crop for your parameters.',                  season: 'Year-round',       confidence: 86 },
  { name: 'Jute',         emoji: '🌿', description: 'Warm temperature and high humidity readings are ideal for jute fibre production.',                    season: 'Kharif (Mar–Jul)', confidence: 84 },
  { name: 'Lentil',       emoji: '🫘', description: 'Cool, dry conditions and moderate nitrogen levels make lentils a smart choice.',                      season: 'Rabi (Oct–Mar)',   confidence: 88 },
];

/* Emoji map for real API results */
const EMOJI_MAP = {
  rice: '🌾', wheat: '🌾', maize: '🌽', corn: '🌽',
  chickpea: '🫘', 'kidney beans': '🫘', lentil: '🫘',
  cotton: '☁️', mango: '🥭', banana: '🍌', coffee: '☕',
  coconut: '🥥', jute: '🌿', pomegranate: '🍎',
  watermelon: '🍉', grapes: '🍇', orange: '🍊',
  apple: '🍎', papaya: '🍈', muskmelon: '🍈',
  pigeonpeas: '🫘', mothbeans: '🫘', mungbean: '🫘',
  blackgram: '🫘', default: '🌱',
};

function getEmoji(cropName) {
  const key = cropName.toLowerCase();
  return EMOJI_MAP[key] || EMOJI_MAP.default;
}

/* Season lookup for real results */
const SEASON_MAP = {
  rice: 'Kharif (Jun–Nov)', wheat: 'Rabi (Nov–Apr)', maize: 'Kharif (Jun–Sep)',
  cotton: 'Kharif (Apr–Nov)', mango: 'Summer (Mar–Jun)', coffee: 'Year-round',
  coconut: 'Year-round', banana: 'Year-round', jute: 'Kharif (Mar–Jul)',
  default: 'Consult local agriculture board for timing.',
};

function getSeason(cropName) {
  return SEASON_MAP[cropName.toLowerCase()] || SEASON_MAP.default;
}

/* Deterministic mock selection from inputs */
function mockPredict(inputs) {
  const sum = Object.values(inputs).reduce((a, b) => a + parseFloat(b || 0), 0);
  const idx = Math.floor(Math.abs(sum)) % CROP_DATABASE.length;
  return CROP_DATABASE[idx];
}

/**
 * predictCrop – Main prediction function.
 *
 * @param {Object} inputs – { nitrogen, phosphorus, potassium,
 *                            temperature, humidity, ph, rainfall }
 * @returns {Promise<Object>} – { name, emoji, description, season, confidence }
 */
export async function predictCrop(inputs) {
  if (MOCK_MODE) {
    await new Promise((res) => setTimeout(res, 1800));
    return mockPredict(inputs);
  }

  /* ─── Real Flask API call ─── */
  const response = await fetch(`${BACKEND_URL}/predict`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      Nitrogen:    inputs.nitrogen,
      Phosphorus:  inputs.phosphorus,
      Potassium:   inputs.potassium,
      temperature: inputs.temperature,
      humidity:    inputs.humidity,
      pH:          inputs.ph,
      rainfall:    inputs.rainfall,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || `Server error: ${response.status}`);
  }

  const data = await response.json();
  const name = data.crop || 'Unknown';

  return {
    name,
    emoji:       getEmoji(name),
    description: `Predicted by your trained Random Forest model with high confidence.`,
    season:      getSeason(name),
    confidence:  data.confidence || 95,
  };
}

export default predictCrop;
